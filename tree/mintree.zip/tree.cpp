#include "tree.hpp"
#include <string>
#include <cmath>
#include <vector>
#include <set>
#include <algorithm>



Edge::Edge(idt from, idt to, float distance) : from(from), to(to), distance(distance){
}

Edge::Edge(Point p1, Point p2){
	from = p1.getid();
	to = p2.getid();
	distance = Point::distance(p1, p2);
}

bool Edge::operator<(const Edge& a) const{
	return std::tie(distance, from,to) < std::tie(a.distance, a.from, a.to);
}

bool Edge::operator==(const Edge& a) const{
	return distance == a.distance && from == a.from && to == a.to;
}


std::vector<Edge> Edge::kruskal(std::vector<Edge> & ingraph){
	std::set<idt> visited;
	std::vector<Edge> ograph;
	sort(ingraph.begin(), ingraph.end());
	for(auto i : ingraph){
		if(!(visited.find(i.from) != visited.end() && visited.find(i.to) != visited.end())){//образуется цикл если пытаемся соединить 2 ребра которые уже в графе
			visited.insert(i.from);
			visited.insert(i.to);
			ograph.push_back(i);
		}
	}
	return ograph;
}


std::vector<Edge> Edge::get_graph(std::istream& input){
	std::vector<Point> pts;
	std::vector<Edge> graph;
	std::string s;

	while(getline(input, s)){
		auto p = Point::parse(s);
		if(p.isvalid())
			pts.push_back(p);
	}

	for(auto i = pts.begin(); i != pts.end(); i++)
		for(auto j = i + 1; j != pts.end(); j++)
			graph.push_back(Edge(*i, *j));

	//std::cout << (*i).getid() << ' ' << (*j).getid() << ' ' << Point::distance(*i, *j) << ' ' << std::endl;}

	return graph;
}

void Edge::print_graph(std::ostream& output, std::vector<Edge>& graph){

	for(Edge i : graph){
		output << i.from << " - " << i.to << std::endl;
	}


}

