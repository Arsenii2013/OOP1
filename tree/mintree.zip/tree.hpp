#pragma once
#include <string>
#include <cmath>
#include <vector>
#include <set>
#include <algorithm>
#include <iterator>
#include <iostream>

#include "point.hpp"

#define idt int
class Edge final{
private:
	idt from, to;
	float distance;

	static bool less(Edge a, Edge b);
public:
	//Point() = default;
	Edge(idt from, idt to, float distance);
	Edge(Point p1, Point p2);
	//~Edge();

	bool operator<(const Edge & a) const;
	bool operator==(const Edge & a) const;

	static std::vector<Edge> kruskal(std::vector<Edge> & graph);

	static std::vector<Edge> get_graph(std::istream& input);

	static void print_graph(std::ostream & output, std::vector<Edge> & graph);
};
